import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;

public class PanagramOrNot {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        input = input.toLowerCase();

        Set<Character> letters = new HashSet<>();
        for (char c : input.toCharArray()) {
            letters.add(c);
        }

        Set<Character> alphabet = new HashSet<>();
        for (char c = 'a'; c <= 'z'; c++) {
            alphabet.add(c);
        }

        boolean isPangram = letters.equals(alphabet);

        if (isPangram) {
            System.out.println("The input string is a pangram.");
        } else {
            System.out.println("The input string is not a pangram.");
        }
    }
}